
How to run
==========
$ ./dsmlr --help
supported options::
  --help                                produce help message
  --seed arg (=12345)                   seed value of random number generator
  --iter arg (=100)                     maximum number of iterations
  --eval_period arg (=1)                frequency of evaluations
  --group arg (=1)                      number of MPI processes in a group
  -b [ --bias ] arg (=0)                bias term put at each datapoint.
  -r [ --reg ] arg (=1)                 regularization parameter
  -p [ --prate ] arg (=0.001)           learning rate for primal variables
  -d [ --drate ] arg (=0.001)           learning rate for dual variables
  --solver arg (=104)                   solver type (104=exactA, 107=wlatest)
  --repeat_block arg (=1)               frequency of repeating sgd update
                                        inside a block
  --proj_period arg (=2)                frequency of projecting primal feasible
                                        space
  --proj arg (=0)                       do you do solution projection onto the
                                        primal feasible space?
  --svrg_period arg (=2)                frequency of computing gradients for
                                        SVRG
  --svrg arg (=0)                       do you use SVRG?
  --split_rows arg (=1)                 true: split data by rows and
                                        communicate primal variables, false:
                                        dual variables are communicated
  --decay arg (=1)                      decay the stepsize
  --train arg                           file name of training data txt files
  --test arg                            file name of testing data txt files
  --64bit arg (=0)                      true: indices in data file are in 64
                                        bit, false: in 32 bit
  --chunk_factor arg (=100)             how large should receive buffer be?
                                        (note: chunk_factor * sizeof(param) =
                                        size of receive buffer)


Examples:
========

To run ds-mlr on the three small datasets:
$ mpirun -np 1 ./dsmlr -r 0.0001 -p 100 --iter 10000 --train /group/ml/data/mlr/CLEF/train2.txt --test /group/ml/data/mlr/CLEF/test2.txt --proj true --proj_period 2 --eval_period 2 --chunk_factor 1000 --seed 1987 | grep grep

$ mpirun -np 1 ./dsmlr -r 8.8810e-05 -p 10000 --iter 10000 --train /group/ml/data/mlr/NEWS20/train2.txt --test /group/ml/data/mlr/NEWS20/test2.txt --proj true --proj_period 2 --eval_period 2 --chunk_factor 1000 --seed 1987 | grep grep

$ mpirun -np 1 ./dsmlr -r 2.2406e-07 -p 10000 --iter 10000 --train /group/ml/data/mlr/LSHTC1-small/train4.txt --test /group/ml/data/mlr/LSHTC1-small/test4.txt --proj true --proj_period 2 --eval_period 2 --chunk_factor 1000 --seed 1987 | grep grep

(Refer supported options above to run the desired solver, default is the exactA solver)



Notes:
======

To run 1-delay (or exactA):
$ mpirun -np 4 ./dsmlr -r 2.2406e-07 -p 10000 --iter 10000 --train /group/ml/data/mlr/LSHTC1-small/train4.txt --test /group/ml/data/mlr/LSHTC1-small/test4.txt --proj true --proj_period 2 --eval_period 2 --chunk_factor 1000 --seed 1987 --solver 104 | grep grep


To run 0-delay (or wlatest):
$ mpirun -np 4 ./dsmlr -r 2.2406e-07 -p 10000 --iter 10000 --train /group/ml/data/mlr/LSHTC1-small/train4.txt --test /group/ml/data/mlr/LSHTC1-small/test4.txt --proj true --proj_period 2 --eval_period 1 --chunk_factor 1000 --seed 1987 --solver 107 | grep grep
